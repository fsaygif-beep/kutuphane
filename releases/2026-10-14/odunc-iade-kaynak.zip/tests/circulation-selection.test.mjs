import assert from "node:assert/strict";
import test from "node:test";
import { matchingRecords, memberActiveLoans } from "../app/circulation-selection.ts";

test("only the selected member's unreturned books are listed, without changing history", () => {
  const rows = [
    { id: 1, studentId: 10, returnedAt: null },
    { id: 2, studentId: 10, returnedAt: "2026-10-13" },
    { id: 3, studentId: 20, returnedAt: null },
    { id: 4, studentId: 10, returnedAt: null },
  ];
  const before = structuredClone(rows);
  assert.deepEqual(memberActiveLoans(rows, 10).map(row => row.id), [1, 4]);
  assert.deepEqual(rows, before);
  assert.deepEqual(memberActiveLoans(rows, 99), []);
});

test("duplicate names and shared ISBNs require a unique member or inventory number", () => {
  const copies = [{ id: 1, dn: "DN-1", isbn: "123" }, { id: 2, dn: "DN-2", isbn: "123" }];
  const keys = row => [row.dn, row.isbn];
  assert.equal(matchingRecords(copies, "123", keys).length, 2);
  assert.deepEqual(matchingRecords(copies, " dn-2 ", keys).map(row => row.id), [2]);
  assert.deepEqual(matchingRecords(copies, "", keys), []);
});

test("returning one book leaves the member's other book in the list", () => {
  const rows = [{ id: 1, studentId: 10, returnedAt: null }, { id: 2, studentId: 10, returnedAt: null }];
  const refreshed = rows.map(row => row.id === 1 ? { ...row, returnedAt: "2026-10-14" } : row);
  assert.deepEqual(memberActiveLoans(refreshed, 10).map(row => row.id), [2]);
  assert.equal(refreshed.length, rows.length);
});

test("Turkish member names match with casing and surrounding whitespace", () => {
  const members = [{ name: "İpek Işık" }];
  assert.equal(matchingRecords(members, " ipek ışık ", row => [row.name]).length, 1);
});

# Ödünç ve İade Ekranları Güncellemesi — 14 Ekim 2026

Durum: Kaynak güncellemesi hazır. Canlı siteye yayımlanmadı.

## Yeni davranış
- Menüde Ödünç Ver ve İade Al ayrı ekranlardır.
- Her iki ekranda üye seçildiğinde yalnızca o kişinin aktif ödünç kitapları listelenir.
- Her kitap satırından ayrı ayrı iade alınabilir; diğer kitaplar listede kalır.
- İade ekranında demirbaş numarasıyla kitap seçildiğinde kitabı alan kişi ve üzerindeki diğer kitaplar gösterilir.
- Seçilen üyenin fotoğrafı ve kitabın kapağı, ayrıca aktif ödünç listelerindeki fotoğraflar gösterilir. Eksik/bozuk görseller için yer tutucu bulunur.
- Ortak ISBN veya aynı ad birden fazla kayda eşleşirse otomatik ilk kayıt seçilmez; üye/demirbaş numarası istenir.
- Başarısız ödünç/iade işleminde kitap araması korunur. Çift gönderim engeli vardır.
- İade aynı mevcut API işlemini kullanır: kaydı silmeden returnedAt güncellenir. Mevcut personel circulation yetkisi iki ekran için korunur.

## Veri koruma
Veritabanı şeması, migrasyonlar, API dosyaları ve D1/R2 bağlamaları değiştirilmedi. Sayım bileşenleri değiştirilmedi. Canlı veri üzerinde yazma/silme yapılmadı.
Bu ZIP kaynak kod paketidir; canlı veritabanı/görsel yedeği değildir.
Önceki gözlem: 4819 kitap, 101 aktif ödünç, seçili sayımda 4723 sayılan ve 96 sayılmayan kitap. Bunlar 14 Ekim tarihli ekran gözlemidir, eşzamanlı değişiklikler nedeniyle tekrar kontrol edilmelidir.

## Doğrulama
- vinext üretim derlemesi başarılı.
- Dört seçim ve aktif ödünç filtreleme testi geçti.
- Tam TypeScript kontrolünde kaynak pakette önceden bulunan hatalar var. Güncelleme öncesi/sonrası hata mesajları, satır numaraları hariç aynı; yeni tip hatası oluşmadı.
- Mevcut rendered-html testi Windows Node ortamında cloudflare: modülünü yükleyemedi. Bu test doğrulanamadı.
- Tarayıcı bağlantısı yanıt vermediği için görsel/etkileşim testi tamamlanamadı.

## Yayımlama engeli ve geçiş şartı
Sites bağlantısı proje için NOT_FOUND döndürüyor; bağlı hesapta sahip veya editör olarak listelenen site yok. Yayımlama yapılmadı. Güncelleme, bu sitenin sahibi/editörü olan Sites hesabından mevcut proje üzerinde uygulanmalı.
Proje kimliği ve mevcut DB/BUCKET bağlamaları korunmalı. Yeni site veya yeni boş veritabanı oluşturulmamalı.
Canlı D1 ve R2 yedeği alınıp geri yüklenebilirliği kontrol edilmeli. Migrasyon/sıfırlama/örnek veri ekleme komutları bu ekran güncellemesi için gerekli değildir.
Yayımlama öncesi ve sonrası aynı okulun aktif ödünç ve seçili sayım kayıtları kimlik ve içerik bazında karşılaştırılmalı. Gerçek öğrenci kayıtlarıyla deneme amaçlı ödünç/iade oluşturulmamalı.
